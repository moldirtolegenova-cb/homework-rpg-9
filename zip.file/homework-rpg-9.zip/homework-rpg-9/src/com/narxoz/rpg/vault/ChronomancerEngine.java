package com.narxoz.rpg.vault;

import com.narxoz.rpg.artifact.GoldAppraiser;
import com.narxoz.rpg.combatant.Hero;
import com.narxoz.rpg.memento.Caretaker;
import java.util.List;

public class ChronomancerEngine {

    public VaultRunResult runVault(List<Hero> party) {
        int mementosCreated = 0;
        int restoredCount = 0;
        int artifactsAppraised = 0;
        Caretaker caretaker = new Caretaker();

        for (Hero hero : party) {
            System.out.println("\n--- " + hero.getName() + " enters the Vault ---");
            
            // 1. Snapshot (Memento)
            caretaker.save(hero.createMemento());
            mementosCreated++;

            // 2. Appraisal (Visitor #2: Gold Appraiser)
            GoldAppraiser appraiser = new GoldAppraiser();
            hero.getInventory().accept(appraiser);
            artifactsAppraised += hero.getInventory().size();
            System.out.println("Inventory Value: " + appraiser.getTotalValue() + "g");

            // 3. Tragedy strikes!
            System.out.println("A temporal trap explodes!");
            hero.takeDamage(50);
            hero.spendGold(100);
            System.out.println("Post-trap state: " + hero);

            // 4. Rewind (Before & After Proof)
            System.out.println("[Chronos] Activating Time Crystal... Rewinding time!");
            hero.restoreFromMemento(caretaker.undo());
            restoredCount++;
            
            // THE CRITICAL MISSING LINE: Showing the restored state
            System.out.println("Restored state:  " + hero);
        }

        return new VaultRunResult(artifactsAppraised, mementosCreated, restoredCount);
    }
}